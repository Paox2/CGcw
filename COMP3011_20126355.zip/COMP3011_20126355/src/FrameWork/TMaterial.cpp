#include "TMaterial.h"

#include "TTexture.h"

#include <tstring.h>

#include <fstream>
#include <stdexcept>

using namespace std;
using namespace glm;

// e.g. input "abc/def.cc", output "abc/"
// e.g. input "def.g", output ""
std::string GetDir(std::string fileName)
{
	string dir;
	auto slashPos = fileName.find_last_of("/\\");
	if (slashPos != string::npos)
	{
		dir = fileName.substr(0, slashPos + 1);
	}
	return dir;
}

// .mtl parser
std::map<std::string, TMaterial> LoadMTL(std::string mtlFileName)
{
	std::map<std::string, TMaterial> materials;
	string currentName;

	string dir = GetDir(mtlFileName);

	unique_ptr<ifstream, void(*)(ifstream *)> pIfs(new ifstream(mtlFileName), [](ifstream *ifs)
		{
			ifs->close();
			delete ifs;
		});

	if (!pIfs->is_open())
		throw runtime_error("Can not open file: " + mtlFileName);

	string line;
	while (getline(*pIfs, line))
	{
		if (line.empty())
			continue;

		if (line[0] == '#')
			continue;

		auto parts = Split(line, " ");
		if (parts[0] == "newmtl")
		{
			if (parts.size() != 2) 
				throw runtime_error("Wrong format: " + mtlFileName);
			currentName = parts[1];
			materials[currentName] = TMaterial();
			materials[currentName].name = currentName;
			continue;
		}

		if (parts[0] == "Ka" ||
			parts[0] == "Kd" ||
			parts[0] == "Ks" ||
			parts[0] == "Ke")
		{
			if (parts.size() != 4) 
				throw runtime_error("Wrong format: " + mtlFileName);

			vec3 val;
			try
			{
				val.x = stof(parts[1]);
				val.y = stof(parts[2]);
				val.z = stof(parts[3]);
			}
			catch (invalid_argument &)
			{
				throw runtime_error("Wrong format: " + mtlFileName);
			}

			if (parts[0] == "Ka")
			{
				materials[currentName].Ka = val;
				continue;
			}
			if (parts[0] == "Kd")
			{
				materials[currentName].Kd = val;
				continue;
			}
			if (parts[0] == "Ks")
			{
				materials[currentName].Ks = val;
				continue;
			}
			if (parts[0] == "Ke")
			{
				materials[currentName].Ks = val;
				continue;
			}
			assert(0 && "not process symbol");
		}

		if (parts[0] == "Ns" ||
			parts[0] == "Ni" ||
			parts[0] == "d" ||
			parts[0] == "illum")
		{
			if (parts.size() != 2) throw runtime_error("Wrong format: " + mtlFileName);
			float fVal;
			int iVal;
			try
			{
				fVal = stof(parts[1]);
				iVal = stoi(parts[1]);
			}
			catch (invalid_argument &)
			{
				throw runtime_error("Wrong format: " + mtlFileName);
			}

			if (parts[0] == "Ns")
			{
				materials[currentName].Ns = fVal;
				continue;
			}
			if (parts[0] == "Ni")
			{
				materials[currentName].Ni = fVal;
				continue;
			}
			if (parts[0] == "d")
			{
				materials[currentName].d = fVal;
				continue;
			}
			if (parts[0] == "illum")
			{
				materials[currentName].illum = iVal;
				continue;
			}
			assert(0 && "not process symbol");
		}

		if (parts[0] == "map_Kd")
		{
			if (parts.size() != 2) 
				throw runtime_error("Wrong format: " + mtlFileName);
			if (materials[currentName].map_Kd) 
				throw runtime_error("Wrong format: " + mtlFileName);

			materials[currentName].map_Kd.reset(new TTexture(dir + "/" + parts[1]));
			continue;
		}

		assert(0 && "symbol need be processing");
	}
	return materials;
}