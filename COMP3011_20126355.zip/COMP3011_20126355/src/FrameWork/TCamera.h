#pragma once

#include <GLFW/glfw3.h>
#include <glm/glm.hpp>

class TCamera
{
protected:
	GLFWwindow *window;
	float screenWidth, screenHeight;
	float fov = 45.0;
	int cameraType;

	// initial position and towards
	glm::vec3 cameraPos = glm::vec3(0.0f, 1.0f, 0.0f);
	glm::vec3 cameraFront = glm::vec3(0.0f, 0.0f, -1.0f);
	glm::vec3 worldUp = glm::vec3(0.0f, 1.0f, 0.0f);

	glm::mat4 view;
	glm::mat4 projection;

	void RefreshViewMatrix();

	void RefreshProjectionMatrix();
public:
	TCamera(GLFWwindow *window);

	// setter
	void SetCameraPos(glm::vec3 pos);

	void SetCameraFront(glm::vec3 dir);

	void SetCameraType(int type);

	// getter
	const glm::mat4 &GetViewMatrix() const;

	const glm::mat4& GetProjection()const;

	const glm::vec3& GetPosition()const;
	glm::vec3 GetTarget();
	const glm::vec3& GetDirection()const;

	// adapt to window size changes
	virtual void ProcessOnSize(float width, float height);

	virtual void ProcessKeyPress() {}

	virtual void ProcessMouseMovement(float xpos, float ypos) {}

	virtual void ProcessKey(int key, int scancode, int action, int mods) {}
};