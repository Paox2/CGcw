#pragma once

#include <glad/glad.h>

#include "TObjLoader.h"

#include "TTexture.h"
#include <tstring.h>

#include <fstream>
#include <stdexcept>
#include <memory>

using namespace std;
using namespace glm;

struct ObjParsedLine
{
	std::string token; // type
	std::string strData; // data
	glm::vec2 vec2Data; // can consider using enum
	glm::vec3 vec3Data;
	struct Face
	{
		vector<int> indices;
		vector<int> textures;
		vector<int> normals;
	};
	Face face;
};

TObjLoader::TObjLoader(std::string fileName)
{
	LoadModel(fileName);
	CalcRange();
}

TObjLoader::~TObjLoader() {
	/*for (TMesh m : meshes) {
		unsigned int* i;
		i = m.GetVAO();
		glDeleteVertexArrays(1, i);
		i = m.GetVBO();
		glDeleteBuffers(1, i);
		i = m.GetEBO();
		glDeleteBuffers(1, i);
	}*/
}

void TObjLoader::Draw(TBaseShader &shader, bool doUniformTextures)
{
	for (unsigned int i = 0; i < meshes.size(); i++)
	{
		meshes[i].Draw(shader, doUniformTextures);
	}
}

void TObjLoader::DrawLines(TBaseShader &shader)
{
	for (unsigned int i = 0; i < meshes.size(); i++)
	{
		meshes[i].DrawLines(shader);
	}
}

glm::vec3 TObjLoader::GetCenter()
{
	return (coord_min + coord_max) / 2.0f;
}

glm::vec3 TObjLoader::GetRange()
{
	return coord_max - coord_min;
}

float TObjLoader::GetMaxScalar()
{
	float ret = coord_max.x - coord_min.x;
	ret = max(ret, coord_max.y - coord_min.y);
	ret = max(ret, coord_max.z - coord_min.z);
	return ret;
}

void TObjLoader::CalcRange()
{
	if (meshes.empty())
		return;

	coord_min = meshes[0].GetMinMax().first;
	coord_max = meshes[0].GetMinMax().second;

	for (auto &mesh : meshes)
	{
		coord_min.x = min(coord_min.x, mesh.GetMinMax().first.x);
		coord_min.y = min(coord_min.y, mesh.GetMinMax().first.y);
		coord_min.z = min(coord_min.z, mesh.GetMinMax().first.z);

		coord_max.x = max(coord_max.x, mesh.GetMinMax().second.x);
		coord_max.y = max(coord_max.y, mesh.GetMinMax().second.y);
		coord_max.z = max(coord_max.z, mesh.GetMinMax().second.z);
	}
}

void ProcessLine(string line, ObjParsedLine &result) try
{
	auto fields = Split(line, " ");
	if (fields.empty())
		return;

	result.token = fields[0];
	if (fields[0] == "#")
	{
		return;
	}

	if (fields[0] == "mtllib" || fields[0] == "usemtl")
	{
		if (fields.size() != 2)
		{
			throw runtime_error("Wrong format at line: " + line);
		}
		result.strData = fields[1];
		return;
	}

	if (fields[0] == "o")
	{
		if (fields.size() != 2)
		{
			throw runtime_error("Wrong format at line: " + line);
		}
		result.strData = fields[1];
		return;
	}

	if (fields[0] == "g")
	{
		if (fields.size() != 2)
		{
			throw runtime_error("Wrong format at line: " + line);
		}
		result.strData = fields[1];
		return;
	}

	if (fields[0] == "v")
	{
		if (fields.size() != 4)
		{
			throw runtime_error("Wrong format at line: " + line);
		}
		result.vec3Data = vec3(stof(fields[1]), stof(fields[2]), stof(fields[3]));
		return;
	}
	else if (fields[0] == "vn")
	{
		if (fields.size() != 4)
		{
			throw runtime_error("Wrong format at line: " + line);
		}
		result.vec3Data = vec3(stof(fields[1]), stof(fields[2]), stof(fields[3]));
		return;
	}
	else if (fields[0] == "vt")
	{
		if (fields.size() != 3)
		{
			throw runtime_error("Wrong format at line: " + line);
		}
		result.vec2Data = vec2(stof(fields[1]), stof(fields[2]));
		return;
	}
	else if (fields[0] == "f")
	{
		if (fields.size() < 4)
		{
			throw runtime_error("Only support triangle. at line: " + line);
		}

		// multiple formats for faces lines, eg
		// f 586/1 1860/2 1781/3
		// f vi/ti/ni
		// where vi is the vertex index
		// ti is the texture index
		// ni is the normal index(optional)
		// note that indexing in the file starts at 1, so we need to correct to start at zero
		vector<int> &indices = result.face.indices;
		vector<int> &textures = result.face.textures;
		vector<int> &normals = result.face.normals;

		for (int i = 1; i < fields.size(); ++i)
		{
			auto &word = fields[i];
			auto numParts = Split(word, "/");

			switch (numParts.size())
			{
			case 1:  // '586' single integer format (vi)
				indices.push_back(stoi(numParts[0]));
				break;
			case 2:  // '586/1' double integer format (vi/ti)
				indices.push_back(stoi(numParts[0]));
				textures.push_back(stoi(numParts[1]));
				break;
			case 3:  // '586/2/1' vi/ti/ni or vi//ni
				indices.push_back(stoi(numParts[0]));
				textures.push_back(stoi(numParts[1]));
				normals.push_back(stoi(numParts[2]));
				break;
			default:
				throw runtime_error("Wrong format at line: " + line);
			}
		}

		if (!(indices.size() == textures.size() && indices.size() == normals.size()))
			throw runtime_error("Wrong point count. at line: " + line);

		return;
	}

	else if (fields[0] == "s")
	{
		// ignore
		return;
	}

	throw runtime_error("Unknown token. at line: " + line);
}
catch (invalid_argument &)
{
	throw runtime_error("Invalid number. at line: " + line);
}

void TObjLoader::LoadModel(const std::string &fileName)
{
	unique_ptr<ifstream, void(*)(ifstream *)> pIfs(new ifstream(fileName), [](ifstream *ifs)
		{
			ifs->close();
			delete ifs;
		});

	//unique_ptr<ifstream> pIfs(new ifstream(fileName));
	//pIfs->close();
	
	std::map<std::string, TMaterial> materials;

	string dir = GetDir(fileName);
	ObjParsedLine temp;
	string line;
	vector<vec3> vlist;
	vector<vec2> vtlist;
	vector<vec3> vnlist;

	vector<Vertex> currVertices;
	vector<unsigned int> currIndices;
	TMaterial currMaterial;
	while (getline(*pIfs, line))
	{
		ProcessLine(line, temp);

		// read '.mtl' file at first which saves the material
		if (temp.token == "mtllib")
		{
			materials = LoadMTL(dir + temp.strData);
			continue;
		}

		if (temp.token == "usemtl")
		{
			currMaterial = materials[temp.strData];
			continue;
		}

		if (temp.token == "v")
		{
			vlist.push_back(temp.vec3Data);
			continue;
		}

		if (temp.token == "vn")
		{
			vnlist.push_back(temp.vec3Data);
			continue;
		}

		if (temp.token == "vt")
		{
			vtlist.push_back(temp.vec2Data);
			continue;
		}

		if (temp.token == "f")
		{
			auto AddPoint = [&](int iInFace)
			{
				// get point data by index descripted in face
				Vertex v;
				v.Position = vlist[temp.face.indices[iInFace] - 1];
				v.TexCoords = vtlist[temp.face.textures[iInFace] - 1];
				v.Normal = vnlist[temp.face.normals[iInFace] - 1];

				unsigned int index = currIndices.size();
				currIndices.push_back(index);
				currVertices.push_back(v);
			};

			// polygon to triangle
			int ptNums = temp.face.indices.size();
			for (int i = 1; i < ptNums-1; ++i)
			{
				AddPoint(0);
				AddPoint(i);
				AddPoint(i + 1);
			}

			// clear temp
			temp.face.indices.clear();
			temp.face.textures.clear();
			temp.face.normals.clear();
			continue;
		}

		if (temp.token == "o")
		{
			if (!currVertices.empty())
			{
				// save tha last one
				meshes.push_back(TMesh(currVertices, currIndices, currMaterial));
				currVertices.clear();
				currIndices.clear();
				//vlist.clear();
				//vtlist.clear();
				//vnlist.clear();
			}
			continue;
		}
	}

	//pIfs->close();
	

	if (!currVertices.empty())
	{
		// save tha last one
		meshes.push_back(TMesh(currVertices, currIndices, currMaterial));
		currVertices.clear();
		currIndices.clear();
		//vlist.clear();
		//vtlist.clear();
		//vnlist.clear();
	}
}
