#pragma once

#include <glm/glm.hpp>

#include <string>
#include <memory>
#include <map>

enum aiTextureType
{
    aiTextureType_DIFFUSE,
    aiTextureType_SPECULAR,
    aiTextureType_NORMALS,
    aiTextureType_HEIGHT
};

class TTexture;
struct TMaterial
{
    std::string name;
    aiTextureType type;
    glm::vec3 Ka;
    glm::vec3 Kd;
    glm::vec3 Ks;
    glm::vec3 Ke;
    float Ns, Ni, d;
    int illum;
    std::shared_ptr<TTexture> map_Kd;
};

// e.g. input "abc/def.cc", output "abc/"
// e.g. input "def.g", output ""
std::string GetDir(std::string fileName);

// key: material name (not file name)
std::map<std::string, TMaterial> LoadMTL(std::string mtlFileName);