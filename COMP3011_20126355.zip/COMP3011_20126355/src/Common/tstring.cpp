#include "tstring.h"

#ifndef WIN32_LEAN_AND_MEAN
#define WIN32_LEAN_AND_MEAN
#endif
#include <Windows.h>
#include <algorithm>
#include <iostream>
#include <memory>
#include <cassert>

using namespace std;

std::vector<std::string> Split(std::string s, std::string seq)
{
	std::vector<std::string> ans;
	auto sepSize = seq.size();
	assert(sepSize > 0);
	string::size_type beg(0);
	while (1)
	{
		auto end = s.find(seq, beg);
		if (end == string::npos)
		{
			ans.push_back(s.substr(beg));
			break;
		}

		ans.push_back(s.substr(beg, end - beg));
		beg = end + sepSize;
	}
	return ans;
}

void TestSplit()
{
	{
		string s = "";
		vector<string> expected = { "" };
		auto result = Split(s,",");
	}
}
