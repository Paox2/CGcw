#pragma once
#include <string>
#include <vector>

#ifndef WIN32_LEAN_AND_MEAN
#define WIN32_LEAN_AND_MEAN
#endif
#include <windows.h>//TEXT macro
#include <tchar.h>

#ifdef _UNICODE

#define tstring wstring

#define tios wios

#define tistream wistream

#define tostream wostream

#define tifstream wifstream

#define tofstream wofstream

#define tstringstream wstringstream

#define tistringstream wistringstream

#define tostringstream wostringstream

#define tstreambuf wstreambuf

#define tcout wcout

#define to_tstring to_wstring

#define to_tstring_from_utf8 utf8_to_wstring

#define utf8_to_tstring utf8_to_wstring

#else

#define tstring string

#define tios ios

#define tistream istream

#define tostream ostream

#define tifstream ifstream

#define tofstream ofstream

#define tstringstream stringstream

#define tistringstream istringstream

#define tostringstream ostringstream

#define tstreambuf streambuf

#define tcout cout

#define to_tstring to_string

#define to_tstring_from_utf8 utf8_to_string

#define utf8_to_tstring utf8_to_string

#endif

std::vector<std::string> Split(std::string s, std::string seq);
void TestSplit();