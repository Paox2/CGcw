#pragma once

#include "TShader.h"
#include "TTexture.h"
#include "TMaterial.h"

#include <glm/glm.hpp>

#include <string>
#include <vector>
#include <memory>

struct Vertex {
	glm::vec3 Position;
	glm::vec3 Normal;
	glm::vec2 TexCoords;
	glm::vec3 Tangent;
	glm::vec3 Bitangent;
};

class TMesh {
public:
	

	TMesh(std::vector<Vertex> vertices, std::vector<unsigned int> indices, TMaterial material);

	void Draw(TBaseShader &shader, bool doUniformTextures = true);

	void DrawLines(TBaseShader & shader);

	glm::vec3 GetCenter() const;
	glm::vec3 GetRange() const;
	std::pair<glm::vec3, glm::vec3> GetMinMax() const;
	float GetMaxScalar() const;

	unsigned int *GetVAO();
	unsigned int *GetVBO();
	unsigned int *GetEBO();

private:
	// mesh data
	std::vector<Vertex> vertices;
	std::vector<unsigned int> indices;
	std::vector<unsigned int> line_indices;
	TMaterial material;

	// rendering vertex object
	unsigned int VAO, VBO, EBO;
	unsigned int line_VAO, line_VBO, line_EBO;


	void setupMesh();
	void setupLine();

	glm::vec3 coord_min, coord_max;
	void CalcRange();

	void Draw_inner(TBaseShader & shader, unsigned int in_VAO,const std::vector<unsigned int>& in_indices, GLuint mode=GL_TRIANGLES, bool doUniformTextures = true);
};

