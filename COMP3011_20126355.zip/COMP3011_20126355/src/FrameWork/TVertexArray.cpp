#include <glad/glad.h>

#include "TVertexArray.h"

#include <assert.h>
#include <algorithm>
#include <numeric>

using namespace std;

TVertexArray::TVertexArray(unsigned int bytes, const float* data, std::initializer_list<int> init_list)
{
	Init(bytes, data, init_list);
}

TVertexArray::~TVertexArray()
{
	glDeleteVertexArrays(1, &VAO);
	glDeleteBuffers(1, &VBO);
}


void TVertexArray::Init(unsigned int bytes, const float* data, std::initializer_list<int> init_list)
{
	this->bytes = bytes;
	glGenVertexArrays(1, &VAO);
	glGenBuffers(1, &VBO);

	glBindVertexArray(VAO);
	glBindBuffer(GL_ARRAY_BUFFER, VBO);
	glBufferData(GL_ARRAY_BUFFER, bytes, data, GL_STATIC_DRAW);

	SetAttribPointer(init_list);
}

void TVertexArray::SetAttribPointer(std::initializer_list<int> init_list)
{
	int num_in_a_group = accumulate(init_list.begin(), init_list.end(), 0);
	int index = 0;
	int start = 0;

	// 1-by-1
	for (auto& n : init_list)
	{
		glVertexAttribPointer(index, n, GL_FLOAT, GL_FALSE, num_in_a_group * sizeof(float), (void*)(start*sizeof(float)));
		glEnableVertexAttribArray(index);
		index++;
		start += n;
	}

	group_count = bytes / sizeof(float) / num_in_a_group;

}

void TVertexArray::Bind()
{
	glBindVertexArray(VAO);
}

void TVertexArray::Draw(unsigned int mode)
{
#ifdef _DEBUG
	int currentVAO;
	glGetIntegerv(GL_VERTEX_ARRAY_BINDING, &currentVAO);
	assert(VAO == currentVAO);
#endif

	glDrawArrays(mode, 0, group_count);

#ifdef _DEBUG
	int err = glGetError();
	assert(err == GL_NO_ERROR);
#endif
}

void TVertexArray::DrawTriangles()
{
	Draw(GL_TRIANGLES);
}

void TVertexArray::DrawLines()
{
	Draw(GL_LINES);
}
