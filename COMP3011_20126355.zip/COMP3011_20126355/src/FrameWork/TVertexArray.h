#pragma once
#include <initializer_list>

class TVertexArray
{
protected:
	unsigned int VAO;
	unsigned int VBO;

	void Init(unsigned int bytes, const float* data, std::initializer_list<int> init_list);
private:
	unsigned int bytes;
	int group_count;

	// x,y,z,r,g,b,s,t {3,3,2} {0,1,2}
	void SetAttribPointer(std::initializer_list<int> init_list);
	virtual void Draw(unsigned int mode);
public:
	TVertexArray(unsigned int bytes, const float* data, std::initializer_list<int> init_list);
	virtual ~TVertexArray();

	virtual void Bind();

	// bind and then draw as lab6
	void DrawTriangles();
	void DrawLines();

#ifdef OPENGL_LEGACY
	void DrawQuads();
#endif
};

