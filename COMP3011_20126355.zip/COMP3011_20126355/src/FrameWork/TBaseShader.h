#pragma once
#include <string>
#include <glm/glm.hpp>

#include <map>

#include "TTexture.h"

class TBaseShader
{
public:
	TBaseShader(std::string vertexShaderSource, std::string fragmentShaderSource, std::string geometryShaderSource = "");
	TBaseShader(const TBaseShader &other) = delete;
	TBaseShader &operator=(const TBaseShader &other) = delete;
	virtual ~TBaseShader();

	void UseProgram()const;

	// overload based on parameter
	void Uniform(std::string name, float f0)const;
	void Uniform(std::string name, float f0, float f1)const;
	void Uniform(std::string name, float f0, float f1, float f2)const;
	void Uniform(std::string name, float f0, float f1, float f2, float f3)const;
	void Uniform(std::string name, int i0)const;
	void Uniform(std::string name, glm::vec2 v2)  const;
	void Uniform(std::string name, glm::vec3 v3)  const;
	void Uniform(std::string name, glm::vec4 v4)  const;
	void Uniform(std::string name, const glm::mat4 &transform)const;

	void Uniform(std::string name, const TTexture &texture);
	void UniformTextureId(std::string name, unsigned int textureId);

	std::string GetFileContent(std::string fileName);

private:
	unsigned int shaderProgram;
	int nextSamplerIndex;
	std::map<std::string, int> mapSamplers; // key: sampler2D name; value: sampler index

	int CompileShader(std::string shaderSource, unsigned int type);
	int CompileShaderByFileName(std::string fileName, unsigned int type);
	inline int GetLocation(std::string name)const;
};
