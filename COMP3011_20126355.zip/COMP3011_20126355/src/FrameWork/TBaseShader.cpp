#include <glad/glad.h>

#include "TBaseShader.h"

#include <glm/gtc/type_ptr.hpp>

#include <fstream>
#include <sstream>

#ifdef _DEBUG
#include <iostream>
#endif

using namespace std;

int TBaseShader::CompileShader(std::string shaderSource, unsigned int type)
{
	// build and compile our shader program
	// ------------------------------------
	// vertex shader
	int shaderId = glCreateShader(type);
	const char *s = shaderSource.c_str();
	glShaderSource(shaderId, 1, &s, NULL);
	glCompileShader(shaderId);

	// check for shader compile errors
	int success;
	glGetShaderiv(shaderId, GL_COMPILE_STATUS, &success);
	if (!success)
	{
		char infoLog[512];
		glGetShaderInfoLog(shaderId, 512, NULL, infoLog);
		throw runtime_error(infoLog);
	}

	return shaderId;
}

int TBaseShader::CompileShaderByFileName(std::string fileName, unsigned int type)
{
	return CompileShader(GetFileContent(fileName),type);
}

TBaseShader::TBaseShader(std::string vertexShaderSource, std::string fragmentShaderSource, std::string geometryShaderSource):
	nextSamplerIndex(0)
{
	int vertexShader = CompileShader(vertexShaderSource, GL_VERTEX_SHADER);
	int fragmentShader = CompileShader(fragmentShaderSource, GL_FRAGMENT_SHADER);

	// link shaders
	shaderProgram = glCreateProgram();
	glAttachShader(shaderProgram, vertexShader);
	glAttachShader(shaderProgram, fragmentShader);
	int geometryShader = 0;
	if (!geometryShaderSource.empty())
	{
		geometryShader = CompileShader(geometryShaderSource, GL_GEOMETRY_SHADER);
		glAttachShader(shaderProgram, geometryShader);
	}

	glLinkProgram(shaderProgram);

	// check for linking errors
	int success;
	glGetProgramiv(shaderProgram, GL_LINK_STATUS, &success);
	if (!success)
	{
		char infoLog[512];
		glGetProgramInfoLog(shaderProgram, 512, NULL, infoLog);
		throw runtime_error(string("ERROR::SHADER::PROGRAM::LINKING_FAILED") + infoLog);
	}

	glDeleteShader(vertexShader);
	glDeleteShader(fragmentShader);
	if (!geometryShaderSource.empty())
	{
		glDeleteShader(geometryShader);
	}
}

TBaseShader::~TBaseShader()
{
	glDeleteProgram(shaderProgram);
}

void TBaseShader::UseProgram()const
{
	glUseProgram(shaderProgram);

#ifdef _DEBUG
	int err = glGetError();
	assert(err == GL_NO_ERROR);
#endif
}

int TBaseShader::GetLocation(std::string name)const
{
#ifdef _DEBUG
	int currentProgram;
	glGetIntegerv(GL_CURRENT_PROGRAM, &currentProgram);
	assert(currentProgram == shaderProgram);
#endif

	int location = glGetUniformLocation(shaderProgram, name.c_str());

	// find or not
#ifdef _DEBUG
	assert(location >= 0);
#endif

	return location;
}

void TBaseShader::Uniform(std::string name, float f0)const
{
	glUniform1f(GetLocation(name), f0);

#ifdef _DEBUG
	int err = glGetError();
	assert(err == GL_NO_ERROR);
#endif
}

void TBaseShader::Uniform(std::string name, float f0, float f1) const
{
	glUniform2f(GetLocation(name), f0, f1);

#ifdef _DEBUG
	int err = glGetError();
	assert(err == GL_NO_ERROR);
#endif
}

void TBaseShader::Uniform(std::string name, float f0, float f1, float f2)const
{
	glUniform3f(GetLocation(name), f0, f1, f2);

#ifdef _DEBUG
	int err = glGetError();
	assert(err == GL_NO_ERROR);
#endif
}

void TBaseShader::Uniform(std::string name, float f0, float f1, float f2, float f3)const
{
	glUniform4f(GetLocation(name), f0, f1, f2, f3);

#ifdef _DEBUG
	int err = glGetError();
	assert(err == GL_NO_ERROR);
#endif
}

void TBaseShader::Uniform(std::string name, int i0)const
{
	glUniform1i(GetLocation(name), i0);

#ifdef _DEBUG
	int err = glGetError();
	assert(err == GL_NO_ERROR);
#endif
}

void TBaseShader::Uniform(std::string name, glm::vec2 v2) const
{
	Uniform(name, v2.x, v2.y);

#ifdef _DEBUG
	int err = glGetError();
	assert(err == GL_NO_ERROR);
#endif
}

void TBaseShader::Uniform(std::string name, glm::vec3 v3)const
{
	Uniform(name, v3.x, v3.y, v3.z);

#ifdef _DEBUG
	int err = glGetError();
	assert(err == GL_NO_ERROR);
#endif
}

void TBaseShader::Uniform(std::string name, glm::vec4 v4) const
{
	Uniform(name, v4.x, v4.y, v4.z, v4.w);

#ifdef _DEBUG
	int err = glGetError();
	assert(err == GL_NO_ERROR);
#endif
}

void TBaseShader::Uniform(std::string name, const glm::mat4 &transform)const
{
	glUniformMatrix4fv(GetLocation(name), 1, GL_FALSE, glm::value_ptr(transform));

#ifdef _DEBUG
	int err = glGetError();
	assert(err == GL_NO_ERROR);
#endif
}


void TBaseShader::Uniform(std::string name, const TTexture &texture)
{
	int textureId = texture.GetId();
	UniformTextureId(name, textureId);
}

void TBaseShader::UniformTextureId(std::string name, unsigned int textureId)
{
	int samplerIndex = 0;
	if (mapSamplers.find(name) == mapSamplers.end())
	{
		mapSamplers[name] = nextSamplerIndex;
		samplerIndex = nextSamplerIndex;
		nextSamplerIndex++;

		cout <<__FILE__<<" ("<<__LINE__ <<") " << name << " samplerIndex=" << samplerIndex << endl;
		assert(nextSamplerIndex < 16);
	}
	else
	{
		samplerIndex = mapSamplers[name];
	}

	glActiveTexture(GL_TEXTURE0 + samplerIndex);
	glBindTexture(GL_TEXTURE_2D, textureId);
	Uniform(name, samplerIndex);
}

std::string TBaseShader::GetFileContent(std::string fileName)
{
	ifstream ifs(fileName);
	if (ifs.fail())
		throw runtime_error("read file failed:" + fileName);
	ostringstream ss;
	ss << ifs.rdbuf();
	ifs.close();

	return ss.str();
}
