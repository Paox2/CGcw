#include "TCamera.h"

#include <glm/gtc/matrix_transform.hpp>

#ifdef _DEBUG
#include <iostream>
#endif
using namespace glm;

using namespace std;

void TCamera::RefreshViewMatrix()
{
	view = glm::lookAt(cameraPos, cameraPos + cameraFront, worldUp);
}

void TCamera::RefreshProjectionMatrix()
{
	if (cameraType == 0)
		projection = glm::perspective(glm::radians(fov), (float)screenWidth / (float)screenHeight, 0.01f, 1e5f);
	else
		projection = glm::ortho(-screenWidth / 4.0f, screenWidth / 4.0f, -screenHeight / 4.0f, screenHeight / 4.0f, 0.01f, 1e5f);
}

TCamera::TCamera(GLFWwindow *window):
	window(window),
	screenWidth(screenWidth),screenHeight(screenHeight),cameraType(0)
{
	int width, height;
	glfwGetWindowSize(window, &width, &height);
	screenWidth = width;
	screenHeight = height;
}

void TCamera::SetCameraPos(glm::vec3 pos)
{
	cameraPos = pos;
	RefreshViewMatrix();
}

void TCamera::SetCameraFront(glm::vec3 dir)
{
	cameraFront = normalize(dir);
	RefreshViewMatrix();
}

void TCamera::SetCameraType(int type)
{
	cameraType = type;
}

const glm::mat4& TCamera::GetViewMatrix()const
{
	return view;
}

const glm::mat4& TCamera::GetProjection()const
{
	return projection;
}

const glm::vec3& TCamera::GetPosition()const
{
	return cameraPos;
}

glm::vec3 TCamera::GetTarget()
{
	return cameraPos+cameraFront;
}

const glm::vec3& TCamera::GetDirection()const
{
	return cameraFront;
}

void TCamera::ProcessOnSize(float width, float height)
{
	screenWidth = width;
	screenHeight = height;
	RefreshProjectionMatrix();
}
