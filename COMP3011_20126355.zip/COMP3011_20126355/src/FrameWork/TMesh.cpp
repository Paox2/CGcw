#pragma once

#include <glad/glad.h>



#include "TMesh.h"

#include <algorithm>

using namespace std;

TMesh::TMesh(std::vector<Vertex> vertices, std::vector<unsigned int> indices, TMaterial material)
{
	this->vertices = vertices;
	this->indices = indices;
	this->material = material;

	line_indices.resize(indices.size() * 2);
	for (int i = 0; i < indices.size() / 3; ++i)
	{
		unsigned int i0 = indices[i * 3 + 0];
		unsigned int i1 = indices[i * 3 + 1];
		unsigned int i2 = indices[i * 3 + 2];

		line_indices[i * 6 + 0] = i0;
		line_indices[i * 6 + 1] = i1;
		line_indices[i * 6 + 2] = i1;
		line_indices[i * 6 + 3] = i2;
		line_indices[i * 6 + 4] = i2;
		line_indices[i * 6 + 5] = i0;
	}

	setupMesh();
	setupLine();

	CalcRange();
}

//TMesh::~TMesh()
//{
//	glDeleteVertexArrays(1, &VAO);
//	glDeleteBuffers(1, &VBO);
//	glDeleteBuffers(1, &EBO);
//}

void TMesh::setupMesh()
{
	glGenVertexArrays(1, &VAO);
	glGenBuffers(1, &VBO);
	glGenBuffers(1, &EBO);

	glBindVertexArray(VAO);
	glBindBuffer(GL_ARRAY_BUFFER, VBO);

	glBufferData(GL_ARRAY_BUFFER, vertices.size() * sizeof(Vertex), &vertices[0], GL_STATIC_DRAW);

	glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, EBO);
	glBufferData(GL_ELEMENT_ARRAY_BUFFER, indices.size() * sizeof(unsigned int),
		&indices[0], GL_STATIC_DRAW);

	// position
	glEnableVertexAttribArray(0);
	glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, sizeof(Vertex), (void*)0);
	// normal
	glEnableVertexAttribArray(1);
	glVertexAttribPointer(1, 3, GL_FLOAT, GL_FALSE, sizeof(Vertex), (void*)offsetof(Vertex, Normal));
	// coords
	glEnableVertexAttribArray(2);
	glVertexAttribPointer(2, 2, GL_FLOAT, GL_FALSE, sizeof(Vertex), (void*)offsetof(Vertex, TexCoords));
	// vertex tangent
	glEnableVertexAttribArray(3);
	glVertexAttribPointer(3, 3, GL_FLOAT, GL_FALSE, sizeof(Vertex), (void*)offsetof(Vertex, Tangent));
	// vertex bitangent
	glEnableVertexAttribArray(4);
	glVertexAttribPointer(4, 3, GL_FLOAT, GL_FALSE, sizeof(Vertex), (void*)offsetof(Vertex, Bitangent));

	glBindVertexArray(0);
}

void TMesh::setupLine()
{
	glGenVertexArrays(1, &line_VAO);
	glGenBuffers(1, &line_VBO);
	glGenBuffers(1, &line_EBO);

	glBindVertexArray(line_VAO);
	glBindBuffer(GL_ARRAY_BUFFER, line_VBO);

	glBufferData(GL_ARRAY_BUFFER, vertices.size() * sizeof(Vertex), &vertices[0], GL_STATIC_DRAW);

	glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, line_EBO);
	glBufferData(GL_ELEMENT_ARRAY_BUFFER, line_indices.size() * sizeof(unsigned int),
		&line_indices[0], GL_STATIC_DRAW);

	// position
	glEnableVertexAttribArray(0);
	glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, sizeof(Vertex), (void*)0);
	// normal
	glEnableVertexAttribArray(1);
	glVertexAttribPointer(1, 3, GL_FLOAT, GL_FALSE, sizeof(Vertex), (void*)offsetof(Vertex, Normal));
	// coords
	glEnableVertexAttribArray(2);
	glVertexAttribPointer(2, 2, GL_FLOAT, GL_FALSE, sizeof(Vertex), (void*)offsetof(Vertex, TexCoords));
	// vertex tangent
	glEnableVertexAttribArray(3);
	glVertexAttribPointer(3, 3, GL_FLOAT, GL_FALSE, sizeof(Vertex), (void*)offsetof(Vertex, Tangent));
	// vertex bitangent
	glEnableVertexAttribArray(4);
	glVertexAttribPointer(4, 3, GL_FLOAT, GL_FALSE, sizeof(Vertex), (void*)offsetof(Vertex, Bitangent));

	glBindVertexArray(0);
}

void TMesh::Draw(TBaseShader & shader, bool doUniformTextures)
{
	Draw_inner(shader, VAO, indices, GL_TRIANGLES,doUniformTextures);
}

void TMesh::DrawLines(TBaseShader & shader)
{
	Draw_inner(shader, line_VAO, line_indices, GL_LINES);
}

std::pair<glm::vec3, glm::vec3> TMesh::GetMinMax() const
{
	return std::pair<glm::vec3, glm::vec3>(coord_min,coord_max);
}


glm::vec3 TMesh::GetCenter()const
{
	return (coord_min + coord_max) / 2.0f;
}

glm::vec3 TMesh::GetRange()const
{
	return coord_max - coord_min;
}

float TMesh::GetMaxScalar()const
{
	float ret = coord_max.x - coord_min.x;
	ret = max(ret, coord_max.y - coord_min.y);
	ret = max(ret, coord_max.z - coord_min.z);
	return ret;
}

void TMesh::CalcRange()
{
	coord_min = vertices[0].Position;
	coord_max = coord_min;

	for (auto& vertex : vertices)
	{
		coord_min.x = min(coord_min.x, vertex.Position.x);
		coord_min.y = min(coord_min.y, vertex.Position.y);
		coord_min.z = min(coord_min.z, vertex.Position.z);

		coord_max.x = max(coord_max.x, vertex.Position.x);
		coord_max.y = max(coord_max.y, vertex.Position.y);
		coord_max.z = max(coord_max.z, vertex.Position.z);
	}
}

void TMesh::Draw_inner(TBaseShader & shader, unsigned int in_VAO, const std::vector<unsigned int>& in_indices, GLuint mode, bool doUniformTextures)
{
	if (doUniformTextures)
	{
		if (material.map_Kd)
		{
			shader.Uniform("material.textureDiffuseNum", 1);
			shader.Uniform("material.textureDiffuse[0]", *material.map_Kd);
		}

	}

	// draw mesh
	glBindVertexArray(in_VAO);
	glDrawElements(mode, in_indices.size(), GL_UNSIGNED_INT, 0);

#ifdef _DEBUG
	int err = glGetError();
	assert(err == GL_NO_ERROR);
#endif

	glBindVertexArray(0);

	// set everything back to defaults once configured.
	glActiveTexture(GL_TEXTURE0);
}

unsigned int* TMesh::GetVAO()
{
	return &VAO;
}

unsigned int* TMesh::GetVBO()
{
	return &VBO;
}

unsigned int* TMesh::GetEBO()
{
	return &EBO;
}

