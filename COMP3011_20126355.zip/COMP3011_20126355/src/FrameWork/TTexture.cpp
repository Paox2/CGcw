#include <glad/glad.h>

#include <stdexcept>
#include <memory>
#include <cassert>

#include "TTexture.h"

using namespace std;

// read file and return its content
unsigned char *LoadFileContent(const char *path, int &filesize)
{
    unsigned char *fileContent = nullptr;
    filesize = 0;
    FILE *pFile = nullptr;
    fopen_s(&pFile, path, "rb");
    if (pFile)
    {
        fseek(pFile, 0, SEEK_END);
        int nLen = ftell(pFile);
        if (nLen > 0)
        {
            rewind(pFile);
            fileContent = new unsigned char[nLen];
            fread(fileContent, sizeof(unsigned char), nLen, pFile);
            filesize = nLen;
        }
        fclose(pFile);
    }
    else
    {
        throw std::runtime_error(string("load file fail:") +path);
    }
    return fileContent;
}

// decode a raw unsigned char data of BMP format to the RGB format data
unsigned char *DecodeBMP(unsigned char *pixelData, int &width, int &height)
{
    if (0x4D42 == *((unsigned short *)pixelData))
    {
        int pixelDataOffset = *((int *)(pixelData + 10));
        width = *((int *)(pixelData + 18));
        height = *((int *)(pixelData + 22));

        unsigned char *pixel = pixelData + pixelDataOffset;

        for (int i = 0; i < width * height * 3; i += 3)
        {
            swap(pixel[i], pixel[i + 2]);
        }

        return pixel;
    }
    else
    {
        throw std::runtime_error(string("not bmp"));
    }

    return nullptr;
}

void FlipVertical(unsigned char *pixelData, int width, int height)
{
    int lineSize = width * 3;
    unique_ptr<unsigned char[]> buf(new unsigned char[lineSize]);
    for (int i = 0; i < height / 2; ++i)
    {
        auto origin = pixelData + lineSize * i;
        auto target = pixelData + lineSize * (height - 1 - i);
        memcpy_s(buf.get(), lineSize, origin, lineSize);
        memcpy_s(origin, lineSize, target, lineSize);
        memcpy_s(target, lineSize, buf.get(), lineSize);
    }
}

TTexture::TTexture(std::string in_filename, bool flipVertically, unsigned int filtering) :filename(in_filename), textureId(0)
{
	glGenTextures(1, const_cast<GLuint *>(&textureId));
	glBindTexture(GL_TEXTURE_2D, textureId);

	glPixelStorei(GL_UNPACK_ALIGNMENT, 1);

	// repeat and filter
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, filtering);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, filtering);
	//GL_LINEAR_MIPMAP_LINEAR  GL_NEAREST

	// load and generate
	int width, height, nrChannels;

    int fileSize;
    unique_ptr<unsigned char[]> fileContent(LoadFileContent(in_filename.c_str(), fileSize));
    unsigned char *data = DecodeBMP(fileContent.get(), width, height);
    nrChannels = 3;

    // flip
    if (!flipVertically)
    {
        FlipVertical(data, width, height);
    }

	if (data)
	{
		GLenum format;
		switch (nrChannels)
		{
		case 1:format = GL_RED; break;
		case 3:format = GL_RGB; break;
		case 4:format = GL_RGBA; break;
		default:
			throw std::runtime_error("Unsupported channels at: " + in_filename);
		}
		glTexImage2D(GL_TEXTURE_2D, 0, format, width, height, 0, format, GL_UNSIGNED_BYTE, data);
		glGenerateMipmap(GL_TEXTURE_2D);
	}
	else
	{
		throw std::runtime_error("Failed to load texture:" + in_filename);
	}
}

TTexture::~TTexture()
{
	glDeleteTextures(1, &textureId);
}

void TTexture::Bind(int samplerIndex) const
{
	glActiveTexture(GL_TEXTURE0 + samplerIndex); // active unit before binding
	glBindTexture(GL_TEXTURE_2D, textureId);

#ifdef _DEBUG
	int err = glGetError();
	assert(err == GL_NO_ERROR);
#endif
}

unsigned int TTexture::GetId() const
{
	return textureId;
}
