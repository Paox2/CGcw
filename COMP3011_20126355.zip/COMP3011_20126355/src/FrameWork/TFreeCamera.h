#pragma once
#include "TCamera.h"
class TFreeCamera :
    public TCamera
{
private:
	bool hideCursor;
	float diffTime = 0.0f;

	void SetMouseCursor(bool enable);
public:
	TFreeCamera(GLFWwindow *window);

	virtual void ProcessKeyPress() override;

	virtual void ProcessMouseMovement(float xpos, float ypos) override;

	virtual void ProcessKey(int key, int scancode, int action, int mods) override;
};

