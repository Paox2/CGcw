#pragma once
#include "TVertexArray.h"
class TPlane :
    public TVertexArray
{
private:
	//x,y,z,normal,texture
	static float vertices[];
public:
	TPlane();
};

