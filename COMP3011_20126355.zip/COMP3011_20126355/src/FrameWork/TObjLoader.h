#pragma once

#include "TMesh.h"
#include "TMaterial.h"




class TObjLoader
{
public:
    TObjLoader(std::string fileName);
	~TObjLoader();

    void Draw(TBaseShader &shader, bool doUniformTextures = true);

    void DrawLines(TBaseShader &shader);

    glm::vec3 GetCenter();
    glm::vec3 GetRange();
    float GetMaxScalar();

private:
    std::vector<TMesh> meshes;
    glm::vec3 coord_min, coord_max;

    void LoadModel(const std::string &fileName);
    void CalcRange();
};