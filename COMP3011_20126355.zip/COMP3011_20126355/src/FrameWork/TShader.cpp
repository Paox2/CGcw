#pragma once

#include "TShader.h"

TShader::TShader(std::string vertexShaderFileName, std::string fragmentShaderFileName, std::string geometryShaderFileName):
	TBaseShader(GetFileContent(vertexShaderFileName), GetFileContent(fragmentShaderFileName), geometryShaderFileName.empty()?"":GetFileContent(geometryShaderFileName) )
{
}
