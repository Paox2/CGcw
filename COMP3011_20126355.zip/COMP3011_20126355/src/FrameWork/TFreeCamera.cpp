#include "TFreeCamera.h"


#include <glm/gtc/matrix_transform.hpp>

void TFreeCamera::SetMouseCursor(bool enable)
{
	glfwSetInputMode(window, GLFW_CURSOR, enable?GLFW_CURSOR_NORMAL:GLFW_CURSOR_DISABLED);
}

TFreeCamera::TFreeCamera(GLFWwindow *window):
	TCamera(window),
	hideCursor(true)
{
	SetMouseCursor(!hideCursor);
}

void TFreeCamera::ProcessKeyPress()
{

	float nowTime = (float)glfwGetTime();
	static float lastTime = nowTime;
	diffTime = nowTime - lastTime;
	lastTime = nowTime;

	float cameraSpeed = diffTime * 5.0f; // adjust accordingly
	if (glfwGetKey(window, GLFW_KEY_W) == GLFW_PRESS)
	{
		glm::vec3 front_xz = cameraFront;
		front_xz.y = 0;
		cameraPos += cameraSpeed * glm::normalize(front_xz);
	}
	if (glfwGetKey(window, GLFW_KEY_S) == GLFW_PRESS)
	{
		glm::vec3 front_xz = cameraFront;
		front_xz.y = 0;
		cameraPos -= cameraSpeed * glm::normalize(front_xz);
	}
	if (glfwGetKey(window, GLFW_KEY_A) == GLFW_PRESS)
	{
		glm::vec3 left = glm::normalize(glm::cross(cameraFront, worldUp));
		cameraPos -= cameraSpeed * left;
	}
	if (glfwGetKey(window, GLFW_KEY_D) == GLFW_PRESS)
	{
		glm::vec3 left = glm::normalize(glm::cross(cameraFront, worldUp));
		cameraPos += cameraSpeed * left;
	}
	if (glfwGetKey(window, GLFW_KEY_LEFT_CONTROL) == GLFW_PRESS)
	{
		cameraPos.y -= cameraSpeed;
#ifdef _DEBUG
		//cout << cameraPos.x << " " << cameraPos.y << " " << cameraPos.z << endl;
#endif
	}
	if (glfwGetKey(window, GLFW_KEY_SPACE) == GLFW_PRESS)
	{
		cameraPos.y += cameraSpeed;
#ifdef _DEBUG
		//cout << cameraPos.x<<" "<<cameraPos.y<<" "<<cameraPos.z << endl;
#endif
	}

	RefreshViewMatrix();
}

void TFreeCamera::ProcessMouseMovement(float xpos, float ypos)
{
	if (!hideCursor)
		return;

	static float lastX, lastY;
	static float yaw = 0.0f, pitch = 0.0f;
	static bool firstMouse = true;
	if (firstMouse)
	{
		lastX = xpos;
		lastY = ypos;
		firstMouse = false;
	}

	float xoffset = xpos - lastX;
	float yoffset = lastY - ypos; // here is opposite since y become greater from bottom to top
	lastX = xpos;
	lastY = ypos;

	float sensitivity = 0.05f;

	yaw += xoffset * sensitivity;
	pitch += yoffset * sensitivity;

	if (pitch > 89.0f)
		pitch = 89.0f;
	if (pitch < -89.0f)
		pitch = -89.0f;

	glm::vec3 front;
	front.x = cos(glm::radians(pitch)) * sin(glm::radians(yaw));//
	front.y = sin(glm::radians(pitch));
	front.z = -cos(glm::radians(pitch)) * cos(glm::radians(yaw));
	cameraFront = glm::normalize(front);

	RefreshViewMatrix();
}

void TFreeCamera::ProcessKey(int key, int scancode, int action, int mods)
{
	if (key == GLFW_KEY_V && action == GLFW_PRESS)
	{
		hideCursor = !hideCursor;

		SetMouseCursor(!hideCursor);
	}
	
	if (key == GLFW_KEY_LEFT_SHIFT && action == GLFW_PRESS)
	{
		if (cameraType == 0)
			SetCameraType(1);
		else
			SetCameraType(0);
		RefreshProjectionMatrix();
	}
}
