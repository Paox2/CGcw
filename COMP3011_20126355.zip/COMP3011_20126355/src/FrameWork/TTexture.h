#pragma once
#include <GLFW/glfw3.h>
#include <string>

class TFrameBuffer;
class TTexture
{
private:
	const std::string filename;
	const GLuint textureId;
public:
	//jpg: channels=3; png: channels=4;
	TTexture(std::string in_filename, bool flipVertically = true, unsigned int filtering = GL_LINEAR);
	TTexture(const TTexture &other) = delete;
	TTexture &operator=(const TTexture &other) = delete;

	~TTexture();

	void Bind(int samplerIndex = 0) const;

	unsigned int GetId() const;

	friend TFrameBuffer;
	friend class TMultiSampleFrameBuffer;
};

