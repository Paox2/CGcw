#pragma once

#include "TBaseShader.h"


class TShader: public TBaseShader
{
public:
	TShader(std::string vertexShaderFileName, std::string fragmentShaderFileName, std::string geometryShaderFileName = "");
};

